<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://www.wellgotrip.com/
 * @since      1.0.0
 *
 * @package    Custom_Login_Template
 * @subpackage Custom_Login_Template/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Custom_Login_Template
 * @subpackage Custom_Login_Template/includes
 * @author     Abhishek Saini <abhisheksaini62358@gmail.com>
 */
class Custom_Login_Template_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
